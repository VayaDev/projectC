#define ID_MYBUTTON 1 
#define ID_BUTTON2 2 
#define ID_BUTTON3 3
#define IDD_DIALOG1 100  